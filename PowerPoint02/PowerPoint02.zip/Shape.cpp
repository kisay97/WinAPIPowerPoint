#include "Shape.h"

Shape::Shape() : p1({ 0,0 }), p2({ 0,0 }) {
	/*empty code*/
}

Shape::Shape(POINT _p1, POINT _p2) {
	int x1, x2, y1, y2;

	if (_p1.x >= _p2.x) {
		x1 = _p2.x;
		x2 = _p1.x;
	}
	else {
		x1 = _p1.x;
		x2 = _p2.x;
	}

	if (_p1.y >= _p2.y) {
		y1 = _p2.y;
		y2 = _p1.y;
	}
	else {
		y1 = _p1.y;
		y2 = _p2.y;
	}

	p1 = { x1,y1 };
	p2 = { x2,y2 };
}

Shape::~Shape() {
	/*empty code*/
}

void Shape::setPosition(POINT _p1, POINT _p2, bool isDrawing) {
	if (isDrawing) {
		p1 = _p1;
		p2 = _p2;
	}
	else {
		int x1, x2, y1, y2;

		if (_p1.x >= _p2.x) {
			x1 = _p2.x;
			x2 = _p1.x;
		}
		else {
			x1 = _p1.x;
			x2 = _p2.x;
		}

		if (_p1.y >= _p2.y) {
			y1 = _p2.y;
			y2 = _p1.y;
		}
		else {
			y1 = _p1.y;
			y2 = _p2.y;
		}

		p1 = { x1,y1 };
		p2 = { x2,y2 };
	}
}

POINT Shape::getPoint1() {
	return p1;
}
POINT Shape::getPoint2() {
	return p2;
}