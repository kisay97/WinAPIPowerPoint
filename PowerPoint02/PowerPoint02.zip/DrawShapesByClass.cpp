#include <windows.h>
#include <list>
#include "Circle.h"
#include "Rect.h"
#include "Line.h"
#include "resource.h"

#ifdef _DEBUG
#pragma comment(linker, "/entry:WinMainCRTStartup /subsystem:console")
#endif

using std::list;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCWSTR lpszClass = L"DrawShapesByClass";

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance
	, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = (WNDPROC)WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		400, 200, 500, 500,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, 0, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return Message.wParam;
}

list<Shape*> shapeList;
bool canDrawing = false;
bool isDrawing = false;
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	static HCURSOR nowCursor;

	switch (iMessage) {
	case WM_CREATE:
		hWndMain = hWnd;
		nowCursor = LoadCursor(NULL, IDC_ARROW);
		return 0;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_Shape_Circle:
			puts("select Circle");
			nowCursor = LoadCursor(NULL, IDC_CROSS);
			canDrawing = true;
			shapeList.push_back(new Circle());
			break;

		case ID_Shape_Rect:
			puts("select Rect");
			nowCursor = LoadCursor(NULL, IDC_CROSS);
			canDrawing = true;
			shapeList.push_back(new Rect());
			break;

		case ID_Shape_Line:
			puts("select Line");
			nowCursor = LoadCursor(NULL, IDC_CROSS);
			canDrawing = true;
			shapeList.push_back(new Line());
			break;
		}

		return 0;

	case WM_LBUTTONDOWN: {
		if (canDrawing) {
			puts("isDrawing");
			isDrawing = true;

			list<Shape*>::iterator itor = shapeList.end(); itor--;
			POINT currentMousePos = { LOWORD(lParam), HIWORD(lParam) };
			printf("MouseX : %d, MouseY : %d\n", currentMousePos.x, currentMousePos.y);
			(*itor)->setPosition(currentMousePos, currentMousePos, isDrawing);
		}
		return 0;
	}

	case WM_LBUTTONUP: {
		nowCursor = LoadCursor(NULL, IDC_ARROW);
		if (isDrawing) {
			puts("endDrawing");
			isDrawing = false;
			canDrawing = false;

			list<Shape*>::iterator itor = shapeList.end(); itor--;
			POINT currentMousePos = { LOWORD(lParam), HIWORD(lParam) };
			printf("MouseX : %d, MouseY : %d\n", currentMousePos.x, currentMousePos.y);
			(*itor)->setPosition((*itor)->getPoint1(), currentMousePos, isDrawing);

			InvalidateRect(hWnd, NULL, true);
		}
		return 0;
	}

	case WM_MOUSEMOVE: {
		if (isDrawing) {
			puts("isDrawing");
			list<Shape*>::iterator itor = shapeList.end(); itor--;
			POINT currentMousePos = { LOWORD(lParam), HIWORD(lParam) };
			(*itor)->setPosition((*itor)->getPoint1(), currentMousePos, isDrawing);

			printf("p1 = (%d,%d), p2 = (%d,%d)\n", (*itor)->getPoint1().x, (*itor)->getPoint1().y, (*itor)->getPoint2().x, (*itor)->getPoint2().y);

			InvalidateRect(hWnd, NULL, true);
		}

		return 0;
	}

	case WM_SETCURSOR:
		if (LOWORD(lParam) == HTCLIENT) {
			SetCursor(nowCursor);
			return TRUE;
		}
		break;

	case WM_PAINT: {
		hdc = BeginPaint(hWnd, &ps);

		list<Shape*>::iterator itor = shapeList.begin();
		for (itor = shapeList.begin(); itor != shapeList.end(); itor++) {
			(*itor)->draw(hdc);
		}

		EndPaint(hWnd, &ps);
		return 0;
	}

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}

	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}