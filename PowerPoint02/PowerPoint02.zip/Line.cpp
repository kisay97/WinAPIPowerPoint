#include "Line.h"

Line::Line() : Shape() {
	/*empty code*/
}

Line::Line(POINT _p1, POINT _p2) {
	p1 = _p1;
	p2 = _p2;
}

Line::~Line() {
	/*empty code*/
}

void Line::setPosition(POINT _p1, POINT _p2, bool isDrawing) {
	p1 = _p1;
	p2 = _p2;
}

bool Line::isCanClick(POINT mousePosition) {
	if (p1.x == p2.x) { // l ���� ����
		if (mousePosition.x <= p1.x + 1 &&
			mousePosition.x >= p1.x - 1 &&
			mousePosition.y >= p1.y - 1 &&
			mousePosition.y <= p2.y + 1) {
			return true;
		}
		else {
			return false;
		}
	}
	else if (p1.y == p2.y) { // �� ���� ����
		if (mousePosition.y <= p1.y + 1 &&
			mousePosition.y >= p1.y - 1 &&
			mousePosition.x >= p1.x - 1 &&
			mousePosition.x <= p2.x + 1) {
			return true;
		}
		else {
			return false;
		}
	}
	else { // ������ ����
		double lineSlope; //���� ����
		double mouseSlope; //���콺�� �������� ����

		//if( !(p1.x-1<=mousePosition.x && p2.x+1>=mousePosition.x && p1.y) )

		//lineSlope = (double)(p2.y - p1.y) / (p2.x - p1.x);
		//if (mousePosition.x == p1.x) {
		//	mouseSlope = (double)(p2.y - mousePosition.y) / (p2.x - mousePosition.x);
		//}
		//else {
		//	mouseSlope = (double)(p1.y - mousePosition.y) / (p1.x - mousePosition.x);
		//}

		return false;
	}
}

void Line::draw(HDC hdc) {
	MoveToEx(hdc, p1.x, p1.y, NULL);
	LineTo(hdc, p2.x, p2.y);
}